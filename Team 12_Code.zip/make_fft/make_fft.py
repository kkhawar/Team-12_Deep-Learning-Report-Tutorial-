#! /usr/bin/env python
# -*- coding: utf-8 -*-

# opensource URL: https://stackoverflow.com/questions/23377665/python-scipy-fft-wav-files

import matplotlib.pyplot as plt
from scipy.fftpack import fft
from scipy.io import wavfile # get the api


for i in range(1, 2, 1):
    # from voice file, do frequency analysis
    fs, data = wavfile.read('./open{}.wav'.format(i))  # load the data
    a = data.T[0]  # this is a two channel soundtrack, I get the first track
    b = [(ele / 2 ** 8.) * 2 - 1 for ele in a]  # this is 8-bit track, b is now normalized on [-1,1)
    c = fft(b)  # calculate fourier transform (complex numbers list)
    d = len(c) / 2  # you only need half of the fft list (real signal symmetry)
    
    # make fft images
    plt.plot(abs(c[:(d - 1)]), 'r')
    plt.axis([0, 15000, 0, 180000])
    plt.savefig('./open{}.png'.format(i))
    plt.close()
