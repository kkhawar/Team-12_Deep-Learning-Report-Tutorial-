#!/usr/bin/env python
# -*- coding:utf-8 -*-

import os
import getpass
import matplotlib.pyplot as plt

from scipy import signal
from scipy.io import wavfil

user_name = getpass.getuser()                                       # User's Name of Computer
abspath_path = '/home/' + str(user_name) + '/AllFile/class/'        # Abspath path of WAV
voice_path = abspath_path + 'voice/'
voice_listdir = os.listdir(voice_path)                              # Count of WAV files
listdir_number = len(voice_listdir)                                 # Lists of WAV files

for number in range(listdir_number):
    wav_file_path = voice_path + 'open' + str(number+1) + '.wav'                            # WAV files path
    postprocessing_image_path = abspath_path + '/image/' + 'open' + str(number+1) + '.jpg'  # Save images files path

    sample_frequency, signalData = wavfile.read(wav_file_path)      # Read WAV files
    plt.specgram(signalData[:,0], Fs=sample_frequency)              # From WAV files to Spectrogram
    plt.axis([0, 3, 0, 22000])                                      # Figures
    plt.savefig(postprocessing_image_path)                          # Save image files