#! /usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from scipy.io import wavfile
import pyaudio
import wave
import cv2


class Recorder(object):
    def __init__(self, channels=1, rate=44100, frames_per_buffer=1024):
        self.channels = channels
        self.rate = rate
        self.frames_per_buffer = frames_per_buffer

    def open(self, fname, mode='wb'):
        return RecordingFile(fname, mode, self.channels, self.rate,
                            self.frames_per_buffer)


class RecordingFile(object):
    def __init__(self, fname, mode, channels,
                rate, frames_per_buffer):
        self.fname = fname
        self.mode = mode
        self.channels = channels
        self.rate = rate
        self.frames_per_buffer = frames_per_buffer
        self._pa = pyaudio.PyAudio()
        self.wavefile = self._prepare_file(self.fname, self.mode)
        self._stream = None

    def __enter__(self):
        return self

    def __exit__(self, exception, value, traceback):
        self.close()

    def record(self, duration):
        self._stream = self._pa.open(format=pyaudio.paInt16,
                                        channels=self.channels,
                                        rate=self.rate,
                                        input=True,
                                        frames_per_buffer=self.frames_per_buffer)
        for _ in range(int(self.rate / self.frames_per_buffer * duration)):
            audio = self._stream.read(self.frames_per_buffer)
            self.wavefile.writeframes(audio)
        return None

    def stop_recording(self):
        self._stream.stop_stream()
        return self

    def get_callback(self):
        def callback(in_data, frame_count, time_info, status):
            self.wavefile.writeframes(in_data)
            return in_data, pyaudio.paContinue
        return callback

    def close(self):
        self._stream.close()
        self._pa.terminate()
        self.wavefile.close()

    def _prepare_file(self, fname, mode='wb'):
        wavefile = wave.open(fname, mode)
        wavefile.setnchannels(self.channels)
        wavefile.setsampwidth(self._pa.get_sample_size(pyaudio.paInt16))
        wavefile.setframerate(self.rate)
        return wavefile


def convert_spectrogram():
    # Make spectrogram using stream voice file
    wav_file_path = './stream_data/record_file.wav'
    postprocessing_image_path = './stream_data/spectrogram_image.jpg'
    sample_frequency, signalData = wavfile.read(wav_file_path)
    plt.specgram(signalData[:, 0], Fs=sample_frequency)
    plt.axis([0, 3, 0, 22000])
    plt.savefig(postprocessing_image_path)


def create_graph():
    # Create tensorflow graph using pre-saved pb file
    with tf.gfile.FastGFile(model_path, 'rb') as f:
        graph_def = tf.GraphDef()
        graph_def.ParseFromString(f.read())
        _ = tf.import_graph_def(graph_def, name='')


def classifier():
    # Load spectrogram
    image_data = tf.gfile.FastGFile(image_path, 'rb').read()

    # Create tensorflow graph using pre-saved pb file
    create_graph()

    with tf.Session() as sess:
        # Using retrained Inception v3, classify the unknown stream voice
        softmax_tensor = sess.graph.get_tensor_by_name('final_result:0')
        predictions = sess.run(softmax_tensor,
                               {'DecodeJpeg/contents:0': image_data})
        predictions = np.squeeze(predictions)

        top_k = predictions.argsort()[-5:][::-1]  # Get top 5 prediction
        f = open(labels_path, 'rb')
        lines = f.readlines()
        labels = [str(w).replace("\n", "") for w in lines]
        for node_id in top_k:
            human_string = labels[node_id]
            score = predictions[node_id]
            identified_people.append(human_string)
            print('%s (score = %.5f)' % (human_string, score))


if __name__ == '__main__':
    model_path = '../inception/learned_model/output_graph.pb'
    labels_path = '../inception/learned_model/output_labels.txt'
    image_path = './stream_data/spectrogram_image.jpg'
    identified_people = []

    for trial_number in range(1, 101, 1):
        print ('########## trial_count: {} ##########'.format(trial_number))

        # Record stream voice and save as wav file
        rec = Recorder(channels=2)
        with rec.open('./stream_data/record_file.wav', 'wb') as recfile:
            recfile.record(duration=3.0)

        # Convert stream voice to spectrogram
        convert_spectrogram()

        # Do classification on stream spectrogram
        classifier()

        # Make UI for classification result
        original = cv2.imread('./registered_peoples/' + identified_people[0] + '.png', cv2.IMREAD_COLOR)
        cv2.imshow('Owner of voice', original)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        identified_people = []
